package q2;

@FunctionalInterface
public interface LengthCalculator {
    int calculate(String name);
}
