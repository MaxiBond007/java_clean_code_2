package Q4;

public interface NameStartWith {
    boolean checkName(String name);

}
